<?php

namespace App\Livewire\Clinet;

use Livewire\Component;

class ApplicationStatus extends Component
{
    public function render()
    {
        return view('livewire.clinet.application-status');
    }
}
