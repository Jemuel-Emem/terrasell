<div class="max-w-6xl mx-auto p-6 bg-white shadow-md rounded-md">
    <h2 class="text-2xl font-bold mb-4">Payments</h2>

    <table class="min-w-full bg-white">
        <thead>
            <tr>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Name</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">MOP</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Amount</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Receipt</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                <th class="px-6 py-3 border-b-2 border-gray-200 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="px-6 py-4 border-b border-gray-200"><?php echo e($payment->name); ?></td>
                    <td class="px-6 py-4 border-b border-gray-200 "><p class="bg-blue-500 text-center rounded-md text-white w-18 "><?php echo e($payment->mop); ?></p></td>
                    <td class="px-6 py-4 border-b border-gray-200"><?php echo e($payment->amount); ?></td>
                    <td class="px-6 py-4 border-b border-gray-200">
                        <a href="<?php echo e(asset('storage/' . $payment->receipt_path)); ?>" target="_blank" class="text-indigo-600 hover:text-indigo-900">View</a>
                    </td>
                    <td class="px-6 py-4 border-b border-gray-200"><?php echo e(ucfirst($payment->status)); ?></td>
                    <td class="px-6 py-4 border-b border-gray-200"><?php echo e($payment->created_at->format('Y-m-d')); ?></td>
                    <td class="px-6 py-4 border-b border-gray-200">
                        <!--[if BLOCK]><![endif]--><?php if($payment->status === 'pending'): ?>
                            <button wire:click="approvePayment(<?php echo e($payment->id); ?>)" class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">Approve</button>
                            <button wire:click="declinePayment(<?php echo e($payment->id); ?>)" class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">Decline</button>
                        <?php else: ?>
                            <span class="text-gray-500"><?php echo e(ucfirst($payment->status)); ?></span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>

    <div class="mt-4">
        <?php echo e($payments->links()); ?>

    </div>
</div>
<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/livewire/admin/payment.blade.php ENDPATH**/ ?>