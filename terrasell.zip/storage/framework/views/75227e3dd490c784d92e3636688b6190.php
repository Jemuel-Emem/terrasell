<div>
    WELCOME TO TERRASELL
</div>
<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/livewire/agent/index.blade.php ENDPATH**/ ?>