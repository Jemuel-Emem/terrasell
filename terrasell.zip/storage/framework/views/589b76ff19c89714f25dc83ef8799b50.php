<div class="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-lg">
    <h2 class="text-2xl font-bold mb-6 text-gray-800">Payment Information</h2>


    <form wire:submit.prevent="submitPayment">

        <div class="mb-4">
            <label for="amortization" class="block text-sm font-medium text-gray-700 mb-2">Select Amortization</label>
            <select wire:model="selectedAmortization" id="amortization"
                class="border border-gray-300 rounded-lg p-3 w-full focus:ring focus:ring-indigo-300 focus:border-indigo-500 transition duration-150 ease-in-out">
                <option value="">Choose an option</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $amortizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amortization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($amortization->id); ?>">
                        <?php echo e($amortization->buyersname); ?> - Phase: <?php echo e($amortization->phase); ?>, Block: <?php echo e($amortization->blockno); ?>, Lot: <?php echo e($amortization->lotno); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['selectedAmortization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>


        <div class="mb-4">
            <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Name</label>
            <input type="text" id="name" wire:model="name" placeholder="Enter your name"
                class="border border-gray-300 rounded-lg p-3 w-full focus:ring focus:ring-indigo-300 focus:border-indigo-500 transition duration-150 ease-in-out">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>


        <div class="mb-4">
            <label for="amount" class="block text-sm font-medium text-gray-700 mb-2">Amount to Pay</label>
            <input type="number" id="amount" wire:model="amount" placeholder="Enter amount to pay"
                class="border border-gray-300 rounded-lg p-3 w-full focus:ring focus:ring-indigo-300 focus:border-indigo-500 transition duration-150 ease-in-out">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>


        <div class="mb-4">
            <label for="mop" class="block text-sm font-medium text-gray-700 mb-2">Mode of Payment</label>
            <select id="mop" wire:model="mop" onchange="toggleReceiptField()"
                class="border border-gray-300 rounded-lg p-3 w-full focus:ring focus:ring-indigo-300 focus:border-indigo-500 transition duration-150 ease-in-out">
                <option value="">Select Mode of Payment</option>
                <option value="gcash">Gcash</option>
                <option value="walkin">Walk In</option>
            </select>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['mop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <!-- Receipt Upload Field (conditionally displayed) -->
        <div class="mb-4" id="receipt-upload" style="display: none;">
            <label for="receipt" class="block text-sm font-medium text-gray-700 mb-2">Upload Receipt</label>
            <input type="file" id="receipt" wire:model="receipt"
                class="border border-gray-300 rounded-lg p-3 w-full focus:ring focus:ring-indigo-300 focus:border-indigo-500 transition duration-150 ease-in-out">
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['receipt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mt-6">
            <button type="submit"
                class="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 focus:outline-none focus:ring focus:ring-green-300 transition duration-150 ease-in-out w-full">
                Submit Payment
            </button>
        </div>
    </form>


    <script>
        function toggleReceiptField() {
            const mopSelect = document.getElementById('mop');
            const receiptUpload = document.getElementById('receipt-upload');
            if (mopSelect.value === 'gcash') {
                receiptUpload.style.display = 'block';
            } else {
                receiptUpload.style.display = 'none';
            }
        }
    </script>

</div>

<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/livewire/client/paymnet.blade.php ENDPATH**/ ?>