<div>


    <h1 class="text-2xl font-bold mb-4">Contract To Sell List</h1>

    <!--[if BLOCK]><![endif]--><?php if($contracts->isEmpty()): ?>
        <p class="text-gray-500">No contracts available.</p>
    <?php else: ?>
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr class="border-b bg-gray-100">
                    
                    <th class="p-2 text-left">Buyer Name</th>
                    <th class="p-2 text-left">Seller Name</th>
                    <th class="p-2 text-left">Land Location</th>
                    
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td class="p-2 border-b"><?php echo e($contract->BuyersName); ?></td>
                        <td class="p-2 border-b"><?php echo e($contract->SellersName); ?></td>
                        <td class="p-2 border-b"><?php echo e($contract->LandLocation); ?></td>


                            

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



</div>
<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/livewire/admin/contract-list.blade.php ENDPATH**/ ?>