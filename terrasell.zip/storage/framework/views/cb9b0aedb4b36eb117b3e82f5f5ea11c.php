<?php if (isset($component)) { $__componentOriginalc1313589dbbcd9696e6695540cbeed4c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class=" ">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('client.land', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-4175489933-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $attributes = $__attributesOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__attributesOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c)): ?>
<?php $component = $__componentOriginalc1313589dbbcd9696e6695540cbeed4c; ?>
<?php unset($__componentOriginalc1313589dbbcd9696e6695540cbeed4c); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/client/land.blade.php ENDPATH**/ ?>