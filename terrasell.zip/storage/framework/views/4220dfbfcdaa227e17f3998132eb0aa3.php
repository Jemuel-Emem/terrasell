<div class="min-h-screen bg-gray-100 p-6">
    <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-2xl font-bold text-center text-gray-800 mb-6">Monthly Amortization</h2>

        <!--[if BLOCK]><![endif]--><?php if($amortizations->isEmpty()): ?>
            <p class="text-center text-gray-600">No amortization records found.</p>
        <?php else: ?>
            <table class="min-w-full bg-white">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border">Area</th>
                        <th class="py-2 px-4 border">Due Date</th>
                        <th class="py-2 px-4 border">Monthly Payment Fee</th>
                        <th class="py-2 px-4 border">Total Fee</th>
                        <th class="py-2 px-4 border">Balance</th>
                        
                        <th class="py-2 px-4 border">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $amortizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amortization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-2 px-4 border text-center"><?php echo e($amortization->area); ?></td>
                            <td class="py-2 px-4 border text-center"> Every <?php echo e(\Carbon\Carbon::parse($amortization->due_date)->format('jS')); ?> of the month
                            </td>
                            <td class="py-2 px-4 border text-center"><?php echo e($amortization->monthlypayment); ?></td>
                            <td class="py-2 px-4 border text-center"><?php echo e($amortization->totalfee); ?></td>
                            <td class="py-2 px-4 border text-center"><?php echo e($amortization->totalpayment); ?></td>
                            
                             <!--[if BLOCK]><![endif]--><?php if($amortization->totalfee>=$amortization->totalpayment): ?>
                             <td class="py-2 px-4 border text-center text-green-500">Paid</td>

                             <?php else: ?>
                             <td class="py-2 px-4 border text-center text-red-500">Not Paid</td>
                             <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\resources\views/livewire/client/monthly-amortization.blade.php ENDPATH**/ ?>