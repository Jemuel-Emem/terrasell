<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['class']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['class']); ?>
<?php foreach (array_filter((['class']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginalb5928a9d264d5523fcff7278f3019a3e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5928a9d264d5523fcff7278f3019a3e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'wireui::components.icons.outline.cloud-upload','data' => ['class' => $class]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('wireui::icons.outline.cloud-upload'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($class)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5928a9d264d5523fcff7278f3019a3e)): ?>
<?php $attributes = $__attributesOriginalb5928a9d264d5523fcff7278f3019a3e; ?>
<?php unset($__attributesOriginalb5928a9d264d5523fcff7278f3019a3e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5928a9d264d5523fcff7278f3019a3e)): ?>
<?php $component = $__componentOriginalb5928a9d264d5523fcff7278f3019a3e; ?>
<?php unset($__componentOriginalb5928a9d264d5523fcff7278f3019a3e); ?>
<?php endif; ?><?php /**PATH C:\Users\Emem\Desktop\Sample quiz\laravel\Terrasell\terrasell\storage\framework\views/656e5269d024a7ecdbe5c7318b639a5c.blade.php ENDPATH**/ ?>