<x-client-layout>
    <div class=" p-2 ">
        <livewire:client.monthly-amortization />
    </div>
</x-client-layout>
