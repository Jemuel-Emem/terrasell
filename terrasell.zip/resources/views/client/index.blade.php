<x-client-layout>
        <div class=" p-2 ">
            <livewire:client.index />
        </div>
</x-client-layout>
