<x-client-layout>
    <div class=" p-2 ">
        <livewire:client.paymnet />
    </div>
</x-client-layout>
