<x-client-layout>
    <div class=" p-2 ">
        <livewire:client.application-status/>
    </div>
</x-client-layout>
