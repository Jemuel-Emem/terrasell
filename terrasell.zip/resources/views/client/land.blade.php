<x-client-layout>
    <div class=" ">
        <livewire:client.land />
    </div>
</x-client-layout>
