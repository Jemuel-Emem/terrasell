<x-agent-layout>

    <div class=" p-2 h-screen">
        <livewire:agent.post-land />
    </div>
</x-agent-layout>
