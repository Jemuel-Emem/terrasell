<x-agent-layout>

    <div class=" p-2 h-screen">
        <livewire:agent.index />
    </div>
</x-agent-layout>
