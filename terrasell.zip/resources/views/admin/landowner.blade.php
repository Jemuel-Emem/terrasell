<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.landowner />
    </div>
</x-admin-layout>
