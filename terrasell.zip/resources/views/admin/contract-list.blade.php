<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.contract-list />
    </div>
</x-admin-layout>
