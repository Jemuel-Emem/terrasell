<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.payment/>
    </div>
</x-admin-layout>
