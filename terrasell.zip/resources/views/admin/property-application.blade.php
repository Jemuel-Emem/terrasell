<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.property-application />
    </div>
</x-admin-layout>
