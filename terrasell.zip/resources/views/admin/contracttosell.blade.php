<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.contracttosell />
    </div>
</x-admin-layout>
