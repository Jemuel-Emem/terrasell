<x-admin-layout>

    <div class=" p-2 h-screen">
        <livewire:admin.monthly-amortization />
    </div>
</x-admin-layout>
